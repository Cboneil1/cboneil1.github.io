# import modules
from machine import UART
from machine import Pin
import time
import uasyncio as asyncio


MAX_MESSAGE_LEN=64
MAX_SELECT_SIZE=20
sender_member=0
recipient_member=0
source_select=0
pitch_value=0
team = [b'B',b'C',b'S',b'Z']
id = b'C'
broadcast = b'X'

# initialize a new UART class
uart = UART(2, 9600,tx=17,rx=16)
# run the init method with more details including baudrate and parity
uart.init(9600, bits=8, parity=None, stop=1) 
# define pin 2 as an output with name led. (Pin 2 is connected to the ESP32-WROOM dev board's onboard blue LED)
led = Pin(2,Pin.OUT)


def send_message(message):
    print('ESP: send message')
    # send_queue.append(message)

def handle_message(message):
    my_string = message.decode('utf-8')
    print('ESP: handling my message',message)
    
async def pitch_info(sender_member, source_select, pitch_value):
    print('Process the pitch info request')
    if not isinstance(sender_member, bytes):  # Ensure correct type
        sender_member = sender_member.encode('utf-8')
    pitch_info_message = b'AZC' + sender_member + b'HerePitchYB'
    uart.write(pitch_info_message)
    await asyncio.sleep(10)

async def pass_recipient(recipient_member,message):
    print('Passing message on',message) #Send the message on its way
    uart.write(message)
    await asyncio.sleep(10)    

async def broadcast_message(message):   #When I get a broadcast message
    print('Handling broadcast message')
    print('Eventually this will do something')
    uart.write(message)
    await asyncio.sleep(10)
    print('Broadcast Passed Onward')

async def pitch_compare(bool_pitch): #When I get a pitch up/down message
    
    if (bool_pitch==1):
        print('If I had a high pitch LED, it would glow')
    else:
        print('If I had a low pitch LED, it would glow')
async def generate_fake_pitch_test():
     print('ESP: sending fake message')
     fake_message_data = 176
     fake_message_selector=0
     fake_message_type=1
     fake_message=b'AZCX' + fake_message_type+fake_message_selector+fake_message_data + b'YB'
     #b'AZC' + sender_member + b'HerePitchYB'
     uart.write(fake_message)
     uart.write(b'AZCX10176YB')
     await asyncio.sleep(10)    



async def process_rx():

    # stream = []
    stream = b''
    message = b''
    send_queue = []
    receiving_message=False

    while True:
        # read one byte
        c = uart.read(1)
        # if c is not empty:
        if c is not None:

            stream+=c
            try:
                if stream[-2:]==b'AZ':
                    print('Start Sequence Bits:')
                    message=stream[-2:-1]
                    receiving_message=True
            except IndexError:
                pass
            try:
                if stream[-2:]==b'YB':
                    message+=stream[-1:]
                    stream=b''
                    receiving_message = False
                    print('End Sequence Bits: message processed:',message)
                    handle_message(message)
                    led.value(led.value()^1)
            
            except IndexError:
                pass
            
            if receiving_message:
                
                message+=c


                if len(message)==3:
                    if not (message[2:3] in team):
                        print('ESP: sender not in team')
                    else:
                        print('ESP: sender in team')

                        sender_member=message[2:3] #Assign a variable for whom we just received this from

                if len(message)==4:
                    if not (message[3:4] in team):
                        print('ESP: receiver not in team')

                    else:
                        print('ESP: receiver in team')
                        if message[3:4]==b'C': #Check for my address
                            if len(message)==7: #Since it is my address, check byte 5
                                select_value=message[4] 
                                if 0 <= message[4] <= 20: #If byte 5 is from 0 to 20
                                    print('Good Selection Range Byte 5')
                                    #Detail fill in 

                                    print('Byte value of: ',select_value)

                                    if select_value == 1: #1 indicates pitch info byte
                                        print('Pitch Info Selected')
                                        #source_select,pitch_value
                                        if not (0<=message[5]<=1): #Source has to be either 0 or 1
                                            print('Bad range for source, try again')
                                        else:
                                            source_select=message[5]
                                            print('Good source value received ', source_select)

                                            if not (0<=message[6]<=255): #has to be in range of 0 to 255
                                                print('Bad Pitch Value, try again')
                                            else:
                                                pitch_value=message[6]
                                                print('Good  Pitch Value Received',pitch_value)
                                                await pitch_info(sender_member,source_select,pitch_value) #Go to pitch info handler

                                    if select_value == 2: #Select value 2 indicates a pitch adjust
                                        print('Pitch Up/Down selected') 
                                        bool_pitch=message[5]
                                        if not (bool_pitch==0 or bool_pitch==1): #Here, 0 indicates false
                                            print('Not a useful comparator, adjust pitch up/down value')
                                        else:
                                            print('Good pitch up/down value ', bool_pitch)

                                    else:
                                        print('I am not equipped to handle this request')
                                else:
                                    print('Please adjust byte 5 selection')
                            elif len(message)>7:
                                print('Message too long') #When len(m) is greater than 6, for my personal messages
                            else:
                                print('Message appears to be missing data') #From len(m)==5, if the message is shorter
                            
                        elif message[3:4]==b'X':
                            print('Broadcast Message Detected')
                            await broadcast_message(message)

                        else:
                            #Not my Address, send it onwards
                            recipient_member=message[3:4]
                            await pass_recipient(recipient_member,message)


                if len(message)>MAX_MESSAGE_LEN:
                    receiving_message = False
                    print('ESP: Message too long, please try a shorter message')
                    message=b''


                
           

        await asyncio.sleep_ms(10)    

async def heartbeat():

    while True:
        print('ESP: sending')
        uart.write(b'AZCXProfessor!HowsItLookin?YB')
        await asyncio.sleep(10)    



async def main():
    while True:
        await asyncio.sleep(1)

asyncio.create_task(process_rx())
asyncio.create_task(heartbeat())

try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()
